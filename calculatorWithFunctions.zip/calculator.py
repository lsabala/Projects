#Recursion!!!!!!!!! - Key Concept 
from art import logo

#Calculator - Basic Operations 
def add(n1, n2):
  return n1 + n2

def subtract(n1, n2):
  return n1 - n2

def multiply(n1, n2):
  return n1 * n2

def divide(n1, n2):
  return n1 / n2

#create dictionary operations where keys are the operator symbols
#values are names of functions
operations = {"+": add,
              "-": subtract, 
              "*": multiply, 
              "/": divide
             }

#recursion function
def calculator(): 
    print(logo)
    num1 = float(input("What's the first number?: "))
    
    #gets keys/symbols of operations
    for symbol in operations.keys():
      print(symbol)
    
    continue_operations = True
    
    while continue_operations == True:
      operation_symbol = input("Pick an operation from the line above: ")
      num2 = float(input("What's the second number?: "))
      #gets value of operation key
      #answer = value equaling function name with parameters supplied to function 
      calculation_function = operations[operation_symbol]
      answer = calculation_function(num1, num2)
      
      print(f"{num1} {operation_symbol} {num2} = {answer}")
      
      
      if input(f"Type 'y' to continue calculating with {answer}, or type 'n' to exit.: ") == "y":
        num1 = answer
      else:
        continue_operations = False

        #recursion, calling calculator function within the calculator function
        calculator()
        
#runs function at the start of project     
calculator()
      
      
